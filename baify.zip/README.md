# Bagify
A Full stack e-commerce platform for Modern &amp; Trendy Bags.
